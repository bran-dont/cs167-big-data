# Lab 1

## Student Info

Full Name: Brandon Tran

E-mail: btran117@ucr.edu

UCR NetID: btran117

Student ID: 862180785

## Answers

***(Q1) What is the name of the created directory?***

btran117_lab1

***(Q2) What do you see at the console output?***

Error: opening registry key 'Software\JavaSoft\Java Runtime Environment'
Error: could not find java.dll
Error: Could not find Java SE Runtime Environment.

***(Q3) What do you see at the output?***

    log4j:WARN No appenders could be found for logger (org.apache.hadoop.metrics2.lib.MutableMetricsFactory).
    log4j:WARN Please initialize the log4j system properly.
    log4j:WARN See http://logging.apache.org/log4j/1.2/faq.html#noconfig for more info.
    Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 0
    	at edu.ucr.cs.cs167.btran117.App.main(App.java:60)
    
    Process finished with exit code 1

***(Q4) What is the output that you see at the console?***

    log4j:WARN No appenders could be found for logger (org.apache.hadoop.metrics2.lib.MutableMetricsFactory).
    log4j:WARN Please initialize the log4j system properly.
    log4j:WARN See http://logging.apache.org/log4j/1.2/faq.html#noconfig for more info.
    
    Process finished with exit code 0

***(Q5) Does it run? Why or why not?***

No, because errors are encountered that prevent program from running

```
Error: opening registry key 'Software\JavaSoft\Java Runtime Environment'
Error: could not find java.dll
Error: Could not find Java SE Runtime Environment.
```